package com.example.insurance.payments;
import com.example.insurance.payments.dto.CreateOrderRequest;
import com.example.insurance.payments.dto.CreateOrderResponse;
import com.example.insurance.payments.dto.VerifyPaymentRequest;
import com.razorpay.RazorpayException;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;
@RestController
@RequestMapping("/api/payments")
@RequiredArgsConstructor
public class PaymentController {
private final PaymentService paymentService;
@PostMapping("/create-order")
public CreateOrderResponse createOrder(Authentication auth, @Valid @RequestBody CreateOrderRequest req)
throws RazorpayException {

return paymentService.createOrder(auth.getName(), req);
}
@PostMapping("/verify")
public void verify(Authentication auth, @Valid @RequestBody VerifyPaymentRequest req) {
paymentService.verifyAndActivatePolicy(auth.getName(), req);
}
}