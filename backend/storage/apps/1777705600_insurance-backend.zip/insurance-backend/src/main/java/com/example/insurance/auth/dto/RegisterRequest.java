package com.example.insurance.auth.dto;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;

import lombok.Getter;
import lombok.Setter;
@Getter
@Setter
public class RegisterRequest {
@NotBlank
public String name;
@Email
@NotBlank
public String email;
@Size(min = 6)
public String password;
}