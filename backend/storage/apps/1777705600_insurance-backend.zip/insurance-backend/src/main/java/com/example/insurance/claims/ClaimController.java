package com.example.insurance.claims;
import com.example.insurance.claims.dto.ClaimCreateRequest;
import com.example.insurance.claims.dto.ClaimStatusUpdateRequest;
import com.example.insurance.policies.UserPolicy;
import com.example.insurance.policies.UserPolicyRepository;
import com.example.insurance.user.User;
import com.example.insurance.user.UserRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;
import java.time.Instant;
import java.util.List;
@RestController
@RequestMapping("/api/claims")
@RequiredArgsConstructor
public class ClaimController {
private final ClaimRepository claimRepo;
private final UserPolicyRepository policyRepo;
private final UserRepository userRepo;
@PostMapping
public Claim create(Authentication auth, @RequestBody ClaimCreateRequest req) {
User user = userRepo.findByEmail(auth.getName()).orElseThrow();
UserPolicy policy = policyRepo.findById(req.getUserPolicyId()).orElseThrow();
if (!policy.getUser().getEmail().equalsIgnoreCase(auth.getName())) {
throw new RuntimeException("Not allowed");
}

Claim c = Claim.builder()
.user(user)
.userPolicy(policy)
.incidentDate(req.getIncidentDate())
.claimAmount(req.getClaimAmount())
.reason(req.getReason())
.status("SUBMITTED")
.createdAt(Instant.now())
.build();
return claimRepo.save(c);
}
@GetMapping("/my")
public List<Claim> my(Authentication auth) {
return claimRepo.findByUser_Email(auth.getName());
}
@PreAuthorize("hasRole('ADMIN')")
@GetMapping
public List<Claim> all() {
return claimRepo.findAll();
}
@PreAuthorize("hasRole('ADMIN')")
@PutMapping("/{id}/status")
public Claim updateStatus(@PathVariable Long id, @RequestBody ClaimStatusUpdateRequest req) {
Claim c = claimRepo.findById(id).orElseThrow();
c.setStatus(req.getStatus());
c.setAdminComment(req.getAdminComment());
return claimRepo.save(c);
}
}