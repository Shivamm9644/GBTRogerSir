package com.example.insurance.plans;
import com.example.insurance.plans.dto.PlanCreateRequest;
import com.example.insurance.plans.dto.PlanUpdateRequest;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import java.util.List;
@RestController
@RequestMapping("/api/plans")
@RequiredArgsConstructor
public class PolicyPlanController {
private final PolicyPlanRepository repo;
@GetMapping
public List<PolicyPlan> list() {
return repo.findAll().stream().filter(PolicyPlan::isActive).toList();
}
@PreAuthorize("hasRole('ADMIN')")
@PostMapping
public PolicyPlan create(@Valid @RequestBody PlanCreateRequest req) {

PolicyPlan p = PolicyPlan.builder()
.title(req.getTitle())
.premiumAmount(req.getPremiumAmount())
.coverageAmount(req.getCoverageAmount())
.tenureMonths(req.getTenureMonths())
.description(req.getDescription())
.isActive(req.getIsActive() == null ? true : req.getIsActive())
.build();
return repo.save(p);
}
@PreAuthorize("hasRole('ADMIN')")
@PutMapping("/{id}")
public PolicyPlan update(@PathVariable Long id, @RequestBody PlanUpdateRequest req) {
PolicyPlan p = repo.findById(id).orElseThrow();
if (req.getTitle() != null) p.setTitle(req.getTitle());
if (req.getPremiumAmount() != null) p.setPremiumAmount(req.getPremiumAmount());
if (req.getCoverageAmount() != null) p.setCoverageAmount(req.getCoverageAmount());
if (req.getTenureMonths() != null) p.setTenureMonths(req.getTenureMonths());
if (req.getDescription() != null) p.setDescription(req.getDescription());
if (req.getIsActive() != null) p.setActive(req.getIsActive());
return repo.save(p);
}
}