package com.example.insurance.payments.dto;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;
@Getter
@Setter
@AllArgsConstructor
public class CreateOrderResponse {
private String razorpayKeyId;
private String orderId;
private Integer amountPaise;
private String currency;
private String planTitle;
}