package com.example.insurance.auth.dto;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;
@Getter
@Setter
@AllArgsConstructor
public class MeResponse {
private Long id;
private String name;
private String email;
private String role;
}