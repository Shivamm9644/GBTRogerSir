package com.example.insurance.auth;
import com.example.insurance.auth.dto.AuthResponse;
import com.example.insurance.auth.dto.LoginRequest;
import com.example.insurance.auth.dto.RegisterRequest;

import com.example.insurance.security.JwtService;
import com.example.insurance.user.Role;
import com.example.insurance.user.User;
import com.example.insurance.user.UserRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import java.time.Instant;
@Service
@RequiredArgsConstructor
public class AuthService {
private final UserRepository userRepository;
private final PasswordEncoder passwordEncoder;
private final AuthenticationManager authenticationManager;
private final JwtService jwtService;
public void register(RegisterRequest req) {
if (userRepository.existsByEmail(req.getEmail().toLowerCase())) {
throw new RuntimeException("Email already registered");
}
User u = User.builder()
.name(req.getName())
.email(req.getEmail().toLowerCase())
.passwordHash(passwordEncoder.encode(req.getPassword()))
.role(Role.USER)
.createdAt(Instant.now())
.build();
userRepository.save(u);
}
public AuthResponse login(LoginRequest req) {
authenticationManager.authenticate(
new UsernamePasswordAuthenticationToken(req.getEmail().toLowerCase(), req.getPassword())
);
User u = userRepository.findByEmail(req.getEmail().toLowerCase())
.orElseThrow(() -> new RuntimeException("User not found"));
String token = jwtService.generateToken(u.getEmail(), u.getRole().name());
return new AuthResponse(token);
}
public User me(String email) {
return userRepository.findByEmail(email.toLowerCase())
.orElseThrow(() -> new RuntimeException("User not found"));
}
}