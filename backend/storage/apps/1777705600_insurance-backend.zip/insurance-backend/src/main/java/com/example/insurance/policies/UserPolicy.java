package com.example.insurance.policies;
import com.example.insurance.payments.Payment;
import com.example.insurance.plans.PolicyPlan;
import com.example.insurance.user.User;
import jakarta.persistence.*;
import lombok.*;
import java.time.LocalDate;
@Entity
@Table(name = "user_policies")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class UserPolicy {
@Id
@GeneratedValue(strategy = GenerationType.IDENTITY)
private Long id;
@ManyToOne(optional = false)
private User user;
@ManyToOne(optional = false)
private PolicyPlan plan;
@Column(nullable = false)
private LocalDate startDate;
@Column(nullable = false)
private LocalDate endDate;
@Column(nullable = false)
private String status; // ACTIVE, EXPIRED, CANCELLED
@OneToOne(optional = false)
private Payment payment;
}