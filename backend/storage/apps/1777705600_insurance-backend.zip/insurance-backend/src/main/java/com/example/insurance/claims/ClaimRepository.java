package com.example.insurance.claims;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;
public interface ClaimRepository extends JpaRepository<Claim, Long> {
List<Claim> findByUser_Email(String email);
}