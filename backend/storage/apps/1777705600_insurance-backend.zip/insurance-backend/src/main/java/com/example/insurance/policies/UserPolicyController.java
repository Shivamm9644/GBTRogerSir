package com.example.insurance.policies;
import lombok.RequiredArgsConstructor;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;
import java.util.List;
@RestController
@RequestMapping("/api/policies")

@RequiredArgsConstructor
public class UserPolicyController {
private final UserPolicyRepository repo;
@GetMapping("/my")
public List<UserPolicy> my(Authentication auth) {
return repo.findByUser_Email(auth.getName());
}
}