package com.example.insurance.claims.dto;
import jakarta.validation.constraints.NotBlank;
import lombok.Getter;
import lombok.Setter;
@Getter
@Setter
public class ClaimStatusUpdateRequest {
@NotBlank
public String status; // IN_REVIEW, APPROVED, REJECTED
public String adminComment;
}