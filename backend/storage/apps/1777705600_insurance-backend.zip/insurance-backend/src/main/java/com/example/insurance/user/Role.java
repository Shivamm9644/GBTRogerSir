package com.example.insurance.user;
public enum Role {
USER,
ADMIN
}