package com.example.insurance.payments.dto;
import jakarta.validation.constraints.NotNull;
import lombok.Getter;
import lombok.Setter;
@Getter
@Setter
public class CreateOrderRequest {
@NotNull
public Long planId;
}