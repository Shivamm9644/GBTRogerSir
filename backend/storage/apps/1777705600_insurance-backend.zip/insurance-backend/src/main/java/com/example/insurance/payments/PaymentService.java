package com.example.insurance.payments;
import com.example.insurance.payments.dto.CreateOrderRequest;
import com.example.insurance.payments.dto.CreateOrderResponse;
import com.example.insurance.payments.dto.VerifyPaymentRequest;
import com.example.insurance.plans.PolicyPlan;
import com.example.insurance.plans.PolicyPlanRepository;
import com.example.insurance.policies.UserPolicy;
import com.example.insurance.policies.UserPolicyRepository;
import com.example.insurance.user.User;
import com.example.insurance.user.UserRepository;
import com.razorpay.Order;
import com.razorpay.RazorpayClient;
import com.razorpay.RazorpayException;
import lombok.RequiredArgsConstructor;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;
import java.nio.charset.StandardCharsets;
import java.time.Instant;
import java.time.LocalDate;
import java.util.HexFormat;
@Service
@RequiredArgsConstructor
public class PaymentService {
private final PolicyPlanRepository planRepo;
private final UserRepository userRepo;
private final PaymentRepository paymentRepo;
private final UserPolicyRepository policyRepo;
@Value("${razorpay.keyId}")
private String razorpayKeyId;
@Value("${razorpay.keySecret}")
private String razorpayKeySecret;
public CreateOrderResponse createOrder(String userEmail, CreateOrderRequest req) throws RazorpayException User user = userRepo.findByEmail(userEmail).orElseThrow();
PolicyPlan plan = planRepo.findById(req.getPlanId()).orElseThrow();
int amountPaise = plan.getPremiumAmount() * 100;
RazorpayClient client = new RazorpayClient(razorpayKeyId, razorpayKeySecret);
JSONObject options = new JSONObject();
options.put("amount", amountPaise);
options.put("currency", "INR");
options.put("receipt", "rcpt_" + System.currentTimeMillis());
Order order = client.orders.create(options);
Payment payment = Payment.builder()
.user(user)
.plan(plan)
.amount(plan.getPremiumAmount())
.currency("INR")
.razorpayOrderId(order.get("id"))
.status("CREATED")
.createdAt(Instant.now())
.build();
paymentRepo.save(payment);
return new CreateOrderResponse(
razorpayKeyId,
order.get("id"),
amountPaise,
"INR",
plan.getTitle()

);
}
public void verifyAndActivatePolicy(String userEmail, VerifyPaymentRequest req) {
User user = userRepo.findByEmail(userEmail).orElseThrow();
PolicyPlan plan = planRepo.findById(req.getPlanId()).orElseThrow();
Payment payment = paymentRepo.findByRazorpayOrderId(req.getRazorpayOrderId())
.orElseThrow(() -> new RuntimeException("Order not found"));
String payload = req.getRazorpayOrderId() + "|" + req.getRazorpayPaymentId();
String expected = hmacSha256(payload, razorpayKeySecret);
if (!expected.equals(req.getRazorpaySignature())) {
payment.setStatus("FAILED");
paymentRepo.save(payment);
throw new RuntimeException("Payment signature verification failed");
}
payment.setStatus("SUCCESS");
payment.setRazorpayPaymentId(req.getRazorpayPaymentId());
paymentRepo.save(payment);
LocalDate start = LocalDate.now();
LocalDate end = start.plusMonths(plan.getTenureMonths());
UserPolicy up = UserPolicy.builder()
.user(user)
.plan(plan)
.startDate(start)
.endDate(end)
.status("ACTIVE")
.payment(payment)
.build();
policyRepo.save(up);
}
private String hmacSha256(String data, String secret) {
try {
Mac sha256 = Mac.getInstance("HmacSHA256");
SecretKeySpec keySpec = new SecretKeySpec(secret.getBytes(StandardCharsets.UTF_8), "HmacSHA256");
sha256.init(keySpec);
byte[] hash = sha256.doFinal(data.getBytes(StandardCharsets.UTF_8));
return HexFormat.of().formatHex(hash);
} catch (Exception e) {
throw new RuntimeException("HMAC error", e);
}
}
}