package com.example.insurance.payments;
import com.example.insurance.plans.PolicyPlan;
import com.example.insurance.user.User;
import jakarta.persistence.*;
import lombok.*;
import java.time.Instant;
@Entity
@Table(name = "payments")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Payment {
@Id
@GeneratedValue(strategy = GenerationType.IDENTITY)
private Long id;
@ManyToOne(optional = false)
private User user;
@ManyToOne(optional = false)
private PolicyPlan plan;
@Column(nullable = false)
private Integer amount; // INR
@Column(nullable = false)
private String currency;
private String razorpayOrderId;
private String razorpayPaymentId;
@Column(nullable = false)
private String status; // CREATED / SUCCESS / FAILED
@Column(nullable = false)
private Instant createdAt;
}