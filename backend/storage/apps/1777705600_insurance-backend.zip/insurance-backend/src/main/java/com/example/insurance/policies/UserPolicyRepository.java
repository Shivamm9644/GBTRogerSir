package com.example.insurance.policies;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;
public interface UserPolicyRepository extends JpaRepository<UserPolicy, Long> {
List<UserPolicy> findByUser_Email(String email);
}