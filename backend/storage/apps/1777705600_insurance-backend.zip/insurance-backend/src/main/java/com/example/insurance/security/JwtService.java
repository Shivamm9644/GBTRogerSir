package com.example.insurance.security;
import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jws;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import io.jsonwebtoken.security.Keys;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import javax.crypto.SecretKey;
import java.util.Date;
@Service
public class JwtService {
private final SecretKey secretKey;
private final int expMinutes;
public JwtService(
@Value("${app.jwt.secret}") String base64Secret,
@Value("${app.jwt.expMinutes}") int expMinutes
) {
this.secretKey = Keys.hmacShaKeyFor(java.util.Base64.getDecoder().decode(base64Secret));
this.expMinutes = expMinutes;
}
public String generateToken(String subject, String role) {
long now = System.currentTimeMillis();
long exp = now + (long) expMinutes * 60_000L;
return Jwts.builder()
.setSubject(subject)
.claim("role", role)
.setIssuedAt(new Date(now))
.setExpiration(new Date(exp))
.signWith(secretKey, SignatureAlgorithm.HS256)
.compact();
}
public Jws<Claims> parse(String token) {
return Jwts.parserBuilder()
.setSigningKey(secretKey)
.build()
.parseClaimsJws(token);
}
public String getEmail(String token) {
return parse(token).getBody().getSubject();
}
public String getRole(String token) {
Object role = parse(token).getBody().get("role");
return role == null ? "" : role.toString();
}
}