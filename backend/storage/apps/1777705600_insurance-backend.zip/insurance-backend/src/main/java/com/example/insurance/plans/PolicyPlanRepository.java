package com.example.insurance.plans;
import org.springframework.data.jpa.repository.JpaRepository;
public interface PolicyPlanRepository extends JpaRepository<PolicyPlan, Long> {}