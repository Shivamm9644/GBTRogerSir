package com.example.insurance.plans.dto;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Getter;
import lombok.Setter;
@Getter
@Setter
public class PlanCreateRequest {
@NotBlank
public String title;
@NotNull
public Integer premiumAmount;
@NotNull
public Integer coverageAmount;
@NotNull
public Integer tenureMonths;
public String description;
public Boolean isActive = true;
}