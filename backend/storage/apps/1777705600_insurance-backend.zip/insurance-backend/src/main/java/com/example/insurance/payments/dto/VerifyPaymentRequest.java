package com.example.insurance.payments.dto;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Getter;
import lombok.Setter;
@Getter
@Setter
public class VerifyPaymentRequest {
@NotNull
public Long planId;
@NotBlank
public String razorpayOrderId;
@NotBlank
public String razorpayPaymentId;
@NotBlank
public String razorpaySignature;
}