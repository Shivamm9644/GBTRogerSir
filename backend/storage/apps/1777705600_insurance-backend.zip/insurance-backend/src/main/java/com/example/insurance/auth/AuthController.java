package com.example.insurance.auth;
import com.example.insurance.auth.dto.AuthResponse;
import com.example.insurance.auth.dto.LoginRequest;
import com.example.insurance.auth.dto.MeResponse;
import com.example.insurance.auth.dto.RegisterRequest;
import com.example.insurance.user.User;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;
@RestController
@RequestMapping("/api/auth")
@RequiredArgsConstructor
public class AuthController {

private final AuthService authService;
@PostMapping("/register")
public void register(@Valid @RequestBody RegisterRequest req) {
authService.register(req);
}
@PostMapping("/login")
public AuthResponse login(@Valid @RequestBody LoginRequest req) {
return authService.login(req);
}
@GetMapping("/me")
public MeResponse me(Authentication authentication) {
User u = authService.me(authentication.getName());
return new MeResponse(u.getId(), u.getName(), u.getEmail(), u.getRole().name());
}
}