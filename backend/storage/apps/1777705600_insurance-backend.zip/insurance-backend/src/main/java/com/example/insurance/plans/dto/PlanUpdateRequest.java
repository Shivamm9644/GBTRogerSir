package com.example.insurance.plans.dto;
import lombok.Getter;
import lombok.Setter;
@Getter
@Setter
public class PlanUpdateRequest {
public String title;
public Integer premiumAmount;
public Integer coverageAmount;
public Integer tenureMonths;
public String description;
public Boolean isActive;
}