package com.example.insurance.claims.dto;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

import lombok.Getter;
import lombok.Setter;
import java.time.LocalDate;
@Getter
@Setter
public class ClaimCreateRequest {
@NotNull
public Long userPolicyId;
@NotNull
public LocalDate incidentDate;
@NotNull
public Integer claimAmount;
@NotBlank
public String reason;
}