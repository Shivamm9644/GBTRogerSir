package com.example.insurance.claims;
import com.example.insurance.policies.UserPolicy;
import com.example.insurance.user.User;
import jakarta.persistence.*;
import lombok.*;
import java.time.Instant;
import java.time.LocalDate;
@Entity
@Table(name = "claims")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Claim {
@Id
@GeneratedValue(strategy = GenerationType.IDENTITY)
private Long id;
@ManyToOne(optional = false)
private User user;
@ManyToOne(optional = false)
private UserPolicy userPolicy;
@Column(nullable = false)
private LocalDate incidentDate;
@Column(nullable = false)
private Integer claimAmount;
@Column(nullable = false, columnDefinition = "TEXT")
private String reason;
@Column(nullable = false)
private String status; // SUBMITTED, IN_REVIEW, APPROVED, REJECTED
private String adminComment;
@Column(nullable = false)
private Instant createdAt;
}