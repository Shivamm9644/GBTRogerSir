package com.shrinetours.api.repository;

import com.shrinetours.api.entity.Place;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface PlaceRepository extends JpaRepository<Place, String> {
    List<Place> findByCityIgnoreCase(String city);
    List<Place> findByNameContainingIgnoreCaseOrCityContainingIgnoreCase(String name, String city);
    List<Place> findBySuggestedTrue();
}
