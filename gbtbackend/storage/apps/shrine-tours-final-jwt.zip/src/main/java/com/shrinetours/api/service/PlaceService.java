package com.shrinetours.api.service;

import com.shrinetours.api.dto.place.AddPlaceToTripRequest;
import com.shrinetours.api.dto.place.PlaceResponse;

import java.util.List;

public interface PlaceService {
    List<PlaceResponse> getPlaces(String city);
    List<PlaceResponse> search(String q);
    List<PlaceResponse> suggested();
    PlaceResponse getPlace(String id);
    void addToTrip(AddPlaceToTripRequest request);
}
