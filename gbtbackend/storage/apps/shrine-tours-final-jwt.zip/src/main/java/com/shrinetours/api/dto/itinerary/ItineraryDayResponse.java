package com.shrinetours.api.dto.itinerary;

import java.util.List;

public record ItineraryDayResponse(
        Integer dayNumber,
        List<ActivityResponse> activities
) {
}
