package com.shrinetours.api.service.impl;

import com.shrinetours.api.dto.weather.WeatherResponse;
import com.shrinetours.api.service.WeatherService;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;

@Service
public class WeatherServiceImpl implements WeatherService {
    @Override
    public WeatherResponse getWeather(String city, LocalDate date) {
        List<String> conditions = List.of("clear", "partly_cloudy", "cloudy", "light_rain");
        int seed = Math.abs((city + date).hashCode());
        String condition = conditions.get(seed % conditions.size());
        int min = 18 + (seed % 8);
        int max = min + 7 + (seed % 5);
        return new WeatherResponse(city, date, condition, min, max, "Travel-friendly weather", seed % 40, "12 km/h", 35 + (seed % 45));
    }
}
