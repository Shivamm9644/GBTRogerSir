package com.shrinetours.api.service.impl;

import com.shrinetours.api.dto.profile.*;
import com.shrinetours.api.entity.PaymentMethod;
import com.shrinetours.api.entity.StaticPage;
import com.shrinetours.api.entity.Subscription;
import com.shrinetours.api.entity.User;
import com.shrinetours.api.exception.ResourceNotFoundException;
import com.shrinetours.api.repository.PaymentMethodRepository;
import com.shrinetours.api.repository.StaticPageRepository;
import com.shrinetours.api.repository.SubscriptionRepository;
import com.shrinetours.api.repository.UserRepository;
import com.shrinetours.api.service.ProfileService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;
import java.util.Map;

@Slf4j
@Service
@RequiredArgsConstructor
@Transactional
public class ProfileServiceImpl implements ProfileService {

    private final UserRepository userRepository;
    private final PaymentMethodRepository paymentMethodRepository;
    private final SubscriptionRepository subscriptionRepository;
    private final StaticPageRepository staticPageRepository;

    @Override
    @Transactional(readOnly = true)
    public ProfileResponse getProfile() {
        return mapProfile(currentUser());
    }

    @Override
    public ProfileResponse updateProfile(UpdateProfileRequest request) {
        User user = currentUser();
        if (request.name() != null) user.setName(request.name());
        if (request.email() != null) user.setEmail(request.email());
        if (request.phone() != null) user.setPhone(request.phone());
        if (request.dob() != null) user.setDob(request.dob());
        return mapProfile(userRepository.save(user));
    }

    @Override
    public UploadAvatarResponse uploadAvatar(MultipartFile file) {
        User user = currentUser();
        String filename = file != null && file.getOriginalFilename() != null ? file.getOriginalFilename() : "avatar.png";
        user.setAvatarUrl("https://cdn.shrinetours.local/profile/" + user.getId() + "/" + filename);
        userRepository.save(user);
        return new UploadAvatarResponse(user.getAvatarUrl());
    }

    @Override
    @Transactional(readOnly = true)
    public List<PaymentMethodResponse> getPayments() {
        return paymentMethodRepository.findByUser(currentUser()).stream().map(this::mapPayment).toList();
    }

    @Override
    @Transactional(readOnly = true)
    public SubscriptionResponse getSubscription() {
        Subscription s = subscriptionRepository.findByUser(currentUser()).orElseThrow(() -> new ResourceNotFoundException("Subscription not found"));
        return new SubscriptionResponse(s.getPlan(), s.getStatus(), s.getRenewsAt(), s.getFeatures());
    }

    @Override
    @Transactional(readOnly = true)
    public List<StaticPageResponse> getPages() {
        return staticPageRepository.findAll().stream().map(this::mapPage).toList();
    }

    @Override
    @Transactional(readOnly = true)
    public StaticPageResponse getPage(String slug) {
        return staticPageRepository.findBySlug(slug).map(this::mapPage).orElseThrow(() -> new ResourceNotFoundException("Page not found"));
    }

    @Override
    public Map<String, Object> deleteAccount() {
        User user = currentUser();
        user.setDeleted(true);
        userRepository.save(user);
        return Map.of("ok", true, "message", "Account deleted successfully");
    }

    private User currentUser() {
        return userRepository.findByEmailIgnoreCase("demo@shrinetours.com")
                .orElseThrow(() -> new ResourceNotFoundException("Demo user not found"));
    }

    private ProfileResponse mapProfile(User user) {
        return new ProfileResponse(user.getId(), user.getName(), user.getEmail(), user.getPhone(), user.getDob(), user.getAvatarUrl(), user.getLevel(), user.getLevelProgress(), user.getTripsCompleted(), user.isPremium());
    }

    private PaymentMethodResponse mapPayment(PaymentMethod p) {
        return new PaymentMethodResponse(p.getId(), p.getType(), p.getLastFour(), p.getHolderName(), p.getExpiry(), p.getPrimaryMethod());
    }

    private StaticPageResponse mapPage(StaticPage p) {
        return new StaticPageResponse(p.getSlug(), p.getTitle(), p.getContent());
    }
}
