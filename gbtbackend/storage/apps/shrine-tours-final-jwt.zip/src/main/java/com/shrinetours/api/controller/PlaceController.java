package com.shrinetours.api.controller;

import com.shrinetours.api.dto.common.ApiResponse;
import com.shrinetours.api.dto.place.AddPlaceToTripRequest;
import com.shrinetours.api.dto.place.PlaceResponse;
import com.shrinetours.api.service.PlaceService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/v1/places")
@RequiredArgsConstructor
public class PlaceController {

    private final PlaceService placeService;

    @GetMapping
    public ResponseEntity<ApiResponse<List<PlaceResponse>>> getPlaces(@RequestParam(required = false) String city) {
        List<PlaceResponse> response = placeService.getPlaces(city);
        return ResponseEntity.ok(ApiResponse.<List<PlaceResponse>>builder().success(true).message("Places fetched successfully").data(response).timestamp(LocalDateTime.now()).path("/api/v1/places").build());
    }

    @GetMapping("/search")
    public ResponseEntity<ApiResponse<List<PlaceResponse>>> search(@RequestParam String q) {
        List<PlaceResponse> response = placeService.search(q);
        return ResponseEntity.ok(ApiResponse.<List<PlaceResponse>>builder().success(true).message("Places search fetched successfully").data(response).timestamp(LocalDateTime.now()).path("/api/v1/places/search").build());
    }

    @GetMapping("/suggested")
    public ResponseEntity<ApiResponse<List<PlaceResponse>>> suggested() {
        List<PlaceResponse> response = placeService.suggested();
        return ResponseEntity.ok(ApiResponse.<List<PlaceResponse>>builder().success(true).message("Suggested places fetched successfully").data(response).timestamp(LocalDateTime.now()).path("/api/v1/places/suggested").build());
    }

    @GetMapping("/{id}")
    public ResponseEntity<ApiResponse<PlaceResponse>> getPlace(@PathVariable String id) {
        PlaceResponse response = placeService.getPlace(id);
        return ResponseEntity.ok(ApiResponse.<PlaceResponse>builder().success(true).message("Place fetched successfully").data(response).timestamp(LocalDateTime.now()).path("/api/v1/places/" + id).build());
    }

    @PostMapping("/add-to-trip")
    public ResponseEntity<ApiResponse<Map<String, Object>>> addToTrip(@Valid @RequestBody AddPlaceToTripRequest request) {
        placeService.addToTrip(request);
        return ResponseEntity.status(HttpStatus.CREATED).body(ApiResponse.<Map<String, Object>>builder().success(true).message("Place added to trip successfully").data(Map.of("ok", true)).timestamp(LocalDateTime.now()).path("/api/v1/places/add-to-trip").build());
    }
}
