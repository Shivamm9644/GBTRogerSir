package com.shrinetours.api.config;

import com.shrinetours.api.entity.*;
import com.shrinetours.api.repository.*;
import lombok.RequiredArgsConstructor;
import org.springframework.boot.CommandLineRunner;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.Instant;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

@Component
@RequiredArgsConstructor
@Transactional
public class DataSeeder implements CommandLineRunner {

    private final UserRepository userRepository;
    private final TripRepository tripRepository;
    private final ItineraryRepository itineraryRepository;
    private final PlaceRepository placeRepository;
    private final PackingListRepository packingListRepository;
    private final PackingCategoryRepository packingCategoryRepository;
    private final PaymentMethodRepository paymentMethodRepository;
    private final SubscriptionRepository subscriptionRepository;
    private final StaticPageRepository staticPageRepository;
    private final TripPlaceRepository tripPlaceRepository;
    private final OtpCodeRepository otpCodeRepository;
    private final PasswordEncoder passwordEncoder;

    @Override
    public void run(String... args) {
        if (userRepository.count() > 0) return;

        User user = userRepository.save(User.builder()
                .name("John Doe")
                .email("demo@shrinetours.com")
                .password(passwordEncoder.encode("password123"))
                .phone("9876543210")
                .dob(LocalDate.of(1990, 1, 1))
                .avatarUrl("https://cdn.shrinetours.local/profile/demo/avatar.png")
                .level("Explorer")
                .levelProgress(new BigDecimal("0.75"))
                .tripsCompleted(5)
                .premium(true)
                .deleted(false)
                .build());

        otpCodeRepository.save(OtpCode.builder()
                .email(user.getEmail())
                .code("123456")
                .expiresAt(Instant.now().plusSeconds(600))
                .consumed(false)
                .build());

        seedPlaces();
        seedPackingTemplates();
        seedPages();

        Trip trip = tripRepository.save(Trip.builder()
                .user(user)
                .city("Bhopal")
                .imageUrl("https://images.unsplash.com/photo-1599661046289-e31897846e41?q=80&w=1200&auto=format&fit=crop")
                .startDate(LocalDate.of(2026, 4, 23))
                .endDate(LocalDate.of(2026, 4, 26))
                .placesCount(3)
                .days(4)
                .adults(2)
                .kids(1)
                .tripStyle("spiritual")
                .build());

        List<Place> bhopalPlaces = placeRepository.findByCityIgnoreCase("Bhopal");
        bhopalPlaces.stream().limit(3).forEach(place ->
                tripPlaceRepository.save(TripPlace.builder().trip(trip).place(place).build()));

        Itinerary itinerary = Itinerary.builder()
                .trip(trip)
                .city("Bhopal")
                .title("Itinerary for Bhopal")
                .days(new ArrayList<>())
                .build();

        for (int i = 1; i <= 4; i++) {
            ItineraryDay day = ItineraryDay.builder()
                    .dayNumber(i)
                    .activities(new ArrayList<>(List.of(
                            Activity.builder().activityTime("08:30 AM").title("Start from Hotel").duration("30 min").cost(BigDecimal.ZERO).icon("car").build(),
                            Activity.builder().activityTime("10:00 AM").title("Temple visit and local sightseeing").duration("3 hr").cost(BigDecimal.valueOf(500)).icon("temple").build()
                    )))
                    .build();
            itinerary.getDays().add(day);
        }

        itineraryRepository.save(itinerary);

        PackingList packingList = PackingList.builder()
                .trip(trip)
                .selectedTransports(new ArrayList<>(List.of("airplane", "car")))
                .categories(new ArrayList<>())
                .build();

        for (PackingCategory template : packingCategoryRepository.findByTemplateOnlyTrue()) {
            PackingCategory category = PackingCategory.builder()
                    .name(template.getName())
                    .icon(template.getIcon())
                    .templateOnly(false)
                    .items(template.getItems().stream()
                            .map(item -> PackingItem.builder()
                                    .name(item.getName())
                                    .checked("Passport".equalsIgnoreCase(item.getName()))
                                    .quantity(item.getQuantity())
                                    .build())
                            .collect(java.util.stream.Collectors.toCollection(ArrayList::new)))
                    .build();
            packingList.getCategories().add(category);
        }

        packingListRepository.save(packingList);

        paymentMethodRepository.saveAll(List.of(
                PaymentMethod.builder().user(user).type("VISA").lastFour("4532").holderName("JOHN DOE").expiry("12/27").primaryMethod(true).build(),
                PaymentMethod.builder().user(user).type("MASTERCARD").lastFour("8891").holderName("JOHN DOE").expiry("09/28").primaryMethod(false).build()
        ));

        subscriptionRepository.save(Subscription.builder()
                .user(user)
                .plan("premium")
                .status("active")
                .renewsAt(LocalDate.of(2026, 12, 1))
                .features(new ArrayList<>(List.of("unlimited_trips", "packing_assistant", "priority_support", "smart_itinerary")))
                .build());
    }

    private void seedPages() {
        staticPageRepository.saveAll(List.of(
                StaticPage.builder().slug("privacy-policy").title("Privacy Policy").content("This is a sample privacy policy page for the Shrine Tours mobile application.").build(),
                StaticPage.builder().slug("terms-and-conditions").title("Terms & Conditions").content("This is a sample terms page. Replace with legal copy before production.").build(),
                StaticPage.builder().slug("about-us").title("About Us").content("Shrine Tours helps users build smart pilgrimage and sightseeing plans.").build()
        ));
    }

    private void seedPlaces() {
        placeRepository.saveAll(List.of(
                Place.builder().city("Bhopal").name("Van Vihar").category("Nature").imageUrl("https://images.unsplash.com/photo-1564507592333-c60657eea523?q=80&w=800&auto=format&fit=crop").typicalDuration("Typically requires 3h").rating(BigDecimal.valueOf(4.8)).reviewsCount(47).verified(true).suggested(false).build(),
                Place.builder().city("Bhopal").name("Sanchi Stupa").category("Historical").imageUrl("https://images.unsplash.com/photo-1524499982521-1ffd58dd89ea?q=80&w=800&auto=format&fit=crop").typicalDuration("Typically requires 2h").rating(BigDecimal.valueOf(4.7)).reviewsCount(110).verified(true).suggested(true).build(),
                Place.builder().city("Bhopal").name("Bhojpur Temple").category("Religious").imageUrl("https://images.unsplash.com/photo-1589308078059-be1415eab4c3?q=80&w=800&auto=format&fit=crop").typicalDuration("Typically requires 1h").rating(BigDecimal.valueOf(4.5)).reviewsCount(66).verified(true).suggested(true).build(),
                Place.builder().city("Bhopal").name("Upper Lake Boat Club").category("Leisure").imageUrl("https://images.unsplash.com/photo-1506744038136-46273834b3fb?q=80&w=800&auto=format&fit=crop").typicalDuration("Typically requires 2h").rating(BigDecimal.valueOf(4.4)).reviewsCount(95).verified(true).suggested(true).build(),
                Place.builder().city("Varanasi").name("Kashi Vishwanath Temple").category("Religious").imageUrl("https://images.unsplash.com/photo-1621416894569-0f39ed31d247?q=80&w=800&auto=format&fit=crop").typicalDuration("Typically requires 2h").rating(BigDecimal.valueOf(4.9)).reviewsCount(1500).verified(true).suggested(true).build(),
                Place.builder().city("Goa").name("Baga Beach").category("Beach").imageUrl("https://images.unsplash.com/photo-1507525428034-b723cf961d3e?q=80&w=800&auto=format&fit=crop").typicalDuration("Typically requires 4h").rating(BigDecimal.valueOf(4.7)).reviewsCount(501).verified(true).suggested(true).build()
        ));
    }

    private void seedPackingTemplates() {
        PackingCategory essentials = PackingCategory.builder()
                .name("Essentials")
                .icon("luggage")
                .templateOnly(true)
                .items(new ArrayList<>(List.of(
                        PackingItem.builder().name("Passport").checked(false).quantity(1).build(),
                        PackingItem.builder().name("Wallet").checked(false).quantity(1).build(),
                        PackingItem.builder().name("Phone Charger").checked(false).quantity(1).build()
                )))
                .build();

        PackingCategory clothing = PackingCategory.builder()
                .name("Clothing")
                .icon("shirt")
                .templateOnly(true)
                .items(new ArrayList<>(List.of(
                        PackingItem.builder().name("T-Shirts").checked(false).quantity(3).build(),
                        PackingItem.builder().name("Comfortable Shoes").checked(false).quantity(1).build()
                )))
                .build();

        PackingCategory spiritual = PackingCategory.builder()
                .name("Temple Visit")
                .icon("sparkles")
                .templateOnly(true)
                .items(new ArrayList<>(List.of(
                        PackingItem.builder().name("Offerings").checked(false).quantity(1).build(),
                        PackingItem.builder().name("Scarf or Shawl").checked(false).quantity(1).build()
                )))
                .build();

        packingCategoryRepository.saveAll(List.of(essentials, clothing, spiritual));
    }
}
