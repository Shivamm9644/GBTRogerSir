package com.shrinetours.api.config;

import lombok.Getter;
import lombok.Setter;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

@Getter
@Setter
@Configuration
@ConfigurationProperties(prefix = "app.analytics.bigquery")
public class BigQueryProperties {
    private boolean enabled = false;
    private String projectId = "";
    private String dataset = "shrine_tours";
    private String eventsTable = "api_events";
    private String credentialsPath = "";
}
