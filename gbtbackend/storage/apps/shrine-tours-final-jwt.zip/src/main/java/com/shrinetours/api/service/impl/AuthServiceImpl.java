package com.shrinetours.api.service.impl;

import com.shrinetours.api.dto.auth.*;
import com.shrinetours.api.entity.OtpCode;
import com.shrinetours.api.entity.User;
import com.shrinetours.api.exception.BadRequestException;
import com.shrinetours.api.exception.ResourceNotFoundException;
import com.shrinetours.api.repository.OtpCodeRepository;
import com.shrinetours.api.repository.UserRepository;
import com.shrinetours.api.security.JwtService;
import com.shrinetours.api.service.AnalyticsService;
import com.shrinetours.api.service.AuthService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.Instant;
import java.time.LocalDate;
import java.util.Map;
import java.util.UUID;

@Slf4j
@Service
@RequiredArgsConstructor
@Transactional
public class AuthServiceImpl implements AuthService {

    private final UserRepository userRepository;
    private final OtpCodeRepository otpCodeRepository;
    private final PasswordEncoder passwordEncoder;
    private final AnalyticsService analyticsService;
    private final JwtService jwtService;

    @Override
    public AuthResponse login(LoginRequest request) {
        log.info("Processing login for email={}", request.email());
        User user = userRepository.findByEmailIgnoreCase(request.email())
                .orElseThrow(() -> new BadRequestException("Invalid email or password"));

        if (user.isDeleted() || !passwordEncoder.matches(request.password(), user.getPassword())) {
            throw new BadRequestException("Invalid email or password");
        }

        analyticsService.track("login", Map.of("email", user.getEmail()));
        return buildAuthResponse(user);
    }

    @Override
    public AuthResponse register(RegisterRequest request) {
        log.info("Processing registration for email={}", request.email());
        if (userRepository.existsByEmailIgnoreCase(request.email())) {
            throw new BadRequestException("Email already registered");
        }

        User user = userRepository.save(
                User.builder()
                        .name(request.name())
                        .email(request.email())
                        .phone(request.phone())
                        .password(passwordEncoder.encode(request.password()))
                        .dob(LocalDate.of(1995, 1, 1))
                        .avatarUrl("https://cdn.shrinetours.local/avatar/default.png")
                        .level("Explorer")
                        .levelProgress(new BigDecimal("0.10"))
                        .tripsCompleted(0)
                        .premium(false)
                        .deleted(false)
                        .build()
        );

        otpCodeRepository.save(
                OtpCode.builder()
                        .email(user.getEmail())
                        .code("123456")
                        .expiresAt(Instant.now().plusSeconds(300))
                        .consumed(false)
                        .build()
        );

        analyticsService.track("register", Map.of("email", user.getEmail()));
        return buildAuthResponse(user);
    }

    @Override
    public AuthResponse googleLogin(GoogleAuthRequest request) {
        log.info("Processing google sign-in for email={}", request.email());
        User user = userRepository.findByEmailIgnoreCase(request.email())
                .orElseGet(() -> userRepository.save(
                        User.builder()
                                .name(request.name())
                                .email(request.email())
                                .phone("")
                                .password(passwordEncoder.encode(UUID.randomUUID().toString()))
                                .dob(LocalDate.of(1995, 1, 1))
                                .avatarUrl("https://cdn.shrinetours.local/avatar/google.png")
                                .level("Explorer")
                                .levelProgress(new BigDecimal("0.10"))
                                .tripsCompleted(0)
                                .premium(false)
                                .deleted(false)
                                .build()
                ));

        analyticsService.track("google_login", Map.of("email", user.getEmail()));
        return buildAuthResponse(user);
    }

    @Override
    public TokenResponse refresh(RefreshRequest request) {
        if (request.refreshToken() == null || request.refreshToken().isBlank()) {
            throw new BadRequestException("Refresh token is required");
        }
        if (!jwtService.isTokenValid(request.refreshToken()) || !jwtService.isRefreshToken(request.refreshToken())) {
            throw new BadRequestException("Invalid refresh token");
        }

        String subject = jwtService.extractSubject(request.refreshToken());
        String newAccessToken = jwtService.generateAccessToken(subject);
        String newRefreshToken = jwtService.generateRefreshToken(subject);

        return new TokenResponse(newAccessToken, newRefreshToken, jwtService.getAccessTokenExpirationSeconds());
    }

    @Override
    public OtpResponse verifyOtp(VerifyOtpRequest request) {
        OtpCode code = otpCodeRepository.findTopByEmailAndCodeAndConsumedFalseOrderByExpiresAtDesc(request.email(), request.otp())
                .orElseThrow(() -> new BadRequestException("Invalid OTP"));

        if (code.getExpiresAt().isBefore(Instant.now())) {
            throw new BadRequestException("OTP expired");
        }

        code.setConsumed(true);
        otpCodeRepository.save(code);
        return new OtpResponse(true, "OTP verified successfully");
    }

    @Override
    public Map<String, Object> logout() {
        log.info("Processing logout");
        return Map.of("ok", true, "message", "Session cleared successfully");
    }

    private AuthResponse buildAuthResponse(User user) {
        String accessToken = jwtService.generateAccessToken(user.getEmail());
        String refreshToken = jwtService.generateRefreshToken(user.getEmail());
        return new AuthResponse(
                accessToken,
                refreshToken,
                jwtService.getAccessTokenExpirationSeconds(),
                new AuthUserResponse(
                        user.getId(),
                        user.getName(),
                        user.getEmail(),
                        user.getPhone(),
                        user.isPremium()
                )
        );
    }
}
