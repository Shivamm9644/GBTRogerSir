package com.shrinetours.api.config;

import com.google.auth.oauth2.GoogleCredentials;
import com.google.cloud.bigquery.BigQuery;
import com.google.cloud.bigquery.BigQueryOptions;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.FileSystemResource;
import org.springframework.util.StringUtils;

import java.io.InputStream;

@Configuration
public class BigQueryConfig {

    @Bean
    @ConditionalOnProperty(prefix = "app.analytics.bigquery", name = "enabled", havingValue = "true")
    public BigQuery bigQuery(BigQueryProperties properties) throws Exception {
        if (!StringUtils.hasText(properties.getCredentialsPath())) {
            throw new IllegalStateException("BigQuery is enabled but credentials-path is empty");
        }
        FileSystemResource resource = new FileSystemResource(properties.getCredentialsPath());
        try (InputStream inputStream = resource.getInputStream()) {
            GoogleCredentials credentials = GoogleCredentials.fromStream(inputStream);
            return BigQueryOptions.newBuilder()
                    .setProjectId(properties.getProjectId())
                    .setCredentials(credentials)
                    .build()
                    .getService();
        }
    }
}
