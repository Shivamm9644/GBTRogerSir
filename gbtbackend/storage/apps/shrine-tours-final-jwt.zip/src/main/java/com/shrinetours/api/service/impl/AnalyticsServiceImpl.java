package com.shrinetours.api.service.impl;

import com.google.cloud.bigquery.BigQuery;
import com.google.cloud.bigquery.InsertAllRequest;
import com.google.cloud.bigquery.TableId;
import com.shrinetours.api.config.BigQueryProperties;
import com.shrinetours.api.service.AnalyticsService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.ObjectProvider;
import org.springframework.stereotype.Service;

import java.time.Instant;
import java.util.HashMap;
import java.util.Map;

@Slf4j
@Service
@RequiredArgsConstructor
public class AnalyticsServiceImpl implements AnalyticsService {

    private final ObjectProvider<BigQuery> bigQueryProvider;
    private final BigQueryProperties properties;

    @Override
    public void track(String eventName, Map<String, Object> payload) {
        if (!properties.isEnabled()) {
            return;
        }

        BigQuery bigQuery = bigQueryProvider.getIfAvailable();
        if (bigQuery == null) {
            log.warn("BigQuery tracking skipped because no BigQuery bean is available");
            return;
        }

        Map<String, Object> row = new HashMap<>();
        row.put("event_name", eventName);
        row.put("payload", payload == null ? "{}" : payload.toString());
        row.put("created_at", Instant.now().toString());

        InsertAllRequest request = InsertAllRequest.newBuilder(
                        TableId.of(properties.getDataset(), properties.getEventsTable()))
                .addRow(row)
                .build();

        bigQuery.insertAll(request);
    }
}
