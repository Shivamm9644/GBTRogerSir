package com.shrinetours.api.service.impl;

import com.shrinetours.api.dto.itinerary.*;
import com.shrinetours.api.entity.Activity;
import com.shrinetours.api.entity.Itinerary;
import com.shrinetours.api.entity.ItineraryDay;
import com.shrinetours.api.entity.Trip;
import com.shrinetours.api.exception.ResourceNotFoundException;
import com.shrinetours.api.repository.ItineraryRepository;
import com.shrinetours.api.service.ItineraryService;
import com.shrinetours.api.service.TripService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

@Slf4j
@Service
@RequiredArgsConstructor
@Transactional
public class ItineraryServiceImpl implements ItineraryService {

    private final ItineraryRepository itineraryRepository;
    private final TripService tripService;

    @Override
    @Transactional(readOnly = true)
    public ItineraryResponse getItinerary(String id) {
        Itinerary itinerary = itineraryRepository.findById(id).orElseThrow(() -> new ResourceNotFoundException("Itinerary not found"));
        return mapItinerary(itinerary);
    }

    @Override
    @Transactional(readOnly = true)
    public List<ItineraryRefResponse> getItineraries() {
        return itineraryRepository.findAllByOrderByCityAsc().stream()
                .map(i -> new ItineraryRefResponse(i.getId(), i.getTrip().getId(), i.getCity(), i.getTitle()))
                .toList();
    }

    @Override
    @Transactional(readOnly = true)
    public List<ActivityResponse> getActivities(String itineraryId) {
        Itinerary itinerary = itineraryRepository.findById(itineraryId).orElseThrow(() -> new ResourceNotFoundException("Itinerary not found"));
        return itinerary.getDays().stream().flatMap(day -> day.getActivities().stream().map(this::mapActivity)).toList();
    }

    @Override
    @Transactional(readOnly = true)
    public ActivityResponse getActivity(String activityId) {
        return itineraryRepository.findAll().stream()
                .flatMap(i -> i.getDays().stream())
                .flatMap(day -> day.getActivities().stream())
                .filter(activity -> activity.getId().equals(activityId))
                .findFirst()
                .map(this::mapActivity)
                .orElseThrow(() -> new ResourceNotFoundException("Activity not found"));
    }

    @Override
    public ItineraryResponse generateItinerary(GenerateItineraryRequest request) {
        Trip trip = ((TripServiceImpl) tripService).getOwnedTrip(request.trip_id());
        Itinerary itinerary = Itinerary.builder()
                .trip(trip)
                .city(request.city())
                .title(request.city() + " Generated Itinerary")
                .days(new ArrayList<>())
                .build();

        for (int i = 1; i <= Math.max(1, request.days()); i++) {
            itinerary.getDays().add(ItineraryDay.builder()
                    .dayNumber(i)
                    .activities(new ArrayList<>(List.of(
                            Activity.builder().activityTime("08:00 AM").title("Start day " + i).duration("30 min").cost(BigDecimal.ZERO).icon("sun").build(),
                            Activity.builder().activityTime("10:00 AM").title("Explore major attraction").duration("2 hr").cost(new BigDecimal("400")).icon("map").build()
                    )))
                    .build());
        }

        return mapItinerary(itineraryRepository.save(itinerary));
    }

    @Override
    public ItineraryResponse updateDay(String itineraryId, UpdateDayRequest request) {
        Itinerary itinerary = itineraryRepository.findById(itineraryId).orElseThrow(() -> new ResourceNotFoundException("Itinerary not found"));
        ItineraryDay day = itinerary.getDays().stream()
                .filter(d -> d.getDayNumber().equals(request.day_number()))
                .findFirst()
                .orElseThrow(() -> new ResourceNotFoundException("Day not found"));

        day.setActivities(request.activities() == null ? new ArrayList<>() : request.activities().stream()
                .map(a -> Activity.builder().activityTime(a.activityTime()).title(a.title()).duration(a.duration()).cost(a.cost()).icon(a.icon()).build())
                .toList());

        return mapItinerary(itineraryRepository.save(itinerary));
    }

    @Override
    public ActivityResponse addActivity(String itineraryId, AddActivityRequest request) {
        Itinerary itinerary = itineraryRepository.findById(itineraryId).orElseThrow(() -> new ResourceNotFoundException("Itinerary not found"));
        ItineraryDay day = itinerary.getDays().stream()
                .filter(d -> d.getDayNumber().equals(request.day_number()))
                .findFirst()
                .orElseGet(() -> {
                    ItineraryDay created = ItineraryDay.builder().dayNumber(request.day_number()).activities(new ArrayList<>()).build();
                    itinerary.getDays().add(created);
                    return created;
                });

        Activity activity = Activity.builder()
                .activityTime(request.activity_time())
                .title(request.title())
                .duration(request.duration())
                .cost(request.cost())
                .icon(request.icon())
                .build();

        day.getActivities().add(activity);
        itineraryRepository.save(itinerary);
        return mapActivity(activity);
    }

    @Override
    public void removeActivity(String activityId) {
        Itinerary itinerary = itineraryRepository.findAll().stream()
                .filter(i -> i.getDays().stream().anyMatch(d -> d.getActivities().stream().anyMatch(a -> a.getId().equals(activityId))))
                .findFirst()
                .orElseThrow(() -> new ResourceNotFoundException("Activity not found"));

        itinerary.getDays().forEach(d -> d.getActivities().removeIf(a -> a.getId().equals(activityId)));
        itineraryRepository.save(itinerary);
    }

    @Override
    public ItineraryResponse reoptimize(String itineraryId, ReoptimizeRequest request) {
        Itinerary itinerary = itineraryRepository.findById(itineraryId).orElseThrow(() -> new ResourceNotFoundException("Itinerary not found"));
        itinerary.getDays().forEach(day ->
                day.getActivities().sort(Comparator.comparing(Activity::getActivityTime))
        );
        return mapItinerary(itineraryRepository.save(itinerary));
    }

    private ItineraryResponse mapItinerary(Itinerary itinerary) {
        return new ItineraryResponse(
                itinerary.getId(),
                itinerary.getTrip().getId(),
                itinerary.getCity(),
                itinerary.getTitle(),
                itinerary.getDays().stream()
                        .map(day -> new ItineraryDayResponse(
                                day.getDayNumber(),
                                day.getActivities().stream().map(this::mapActivity).toList()
                        ))
                        .toList()
        );
    }

    private ActivityResponse mapActivity(Activity activity) {
        return new ActivityResponse(activity.getId(), activity.getActivityTime(), activity.getTitle(), activity.getDuration(), activity.getCost(), activity.getIcon());
    }
}
