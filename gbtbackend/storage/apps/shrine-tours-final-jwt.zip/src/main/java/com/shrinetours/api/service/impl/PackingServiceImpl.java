package com.shrinetours.api.service.impl;

import com.shrinetours.api.dto.packing.*;
import com.shrinetours.api.entity.PackingCategory;
import com.shrinetours.api.entity.PackingItem;
import com.shrinetours.api.entity.PackingList;
import com.shrinetours.api.entity.Trip;
import com.shrinetours.api.exception.ResourceNotFoundException;
import com.shrinetours.api.repository.PackingCategoryRepository;
import com.shrinetours.api.repository.PackingListRepository;
import com.shrinetours.api.service.PackingService;
import com.shrinetours.api.service.TripService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Slf4j
@Service
@RequiredArgsConstructor
@Transactional
public class PackingServiceImpl implements PackingService {

    private final PackingListRepository packingListRepository;
    private final PackingCategoryRepository packingCategoryRepository;
    private final TripService tripService;

    @Override
    @Transactional(readOnly = true)
    public PackingResponse getPacking(String tripId) {
        PackingList packingList = getPackingList(tripId);
        return mapPacking(packingList);
    }

    @Override
    @Transactional(readOnly = true)
    public List<PackingTemplateResponse> getCategories() {
        return packingCategoryRepository.findByTemplateOnlyTrue().stream()
                .map(c -> new PackingTemplateResponse(c.getId(), c.getName(), c.getIcon(), c.getItems().stream().map(PackingItem::getName).toList()))
                .toList();
    }

    @Override
    public PackingResponse addItem(String tripId, AddPackingItemRequest request) {
        PackingList packingList = getPackingList(tripId);
        PackingCategory category = packingList.getCategories().stream()
                .filter(c -> c.getId().equals(request.category_id()))
                .findFirst()
                .orElseThrow(() -> new ResourceNotFoundException("Category not found"));

        category.getItems().add(PackingItem.builder().name(request.name()).quantity(request.quantity()).checked(false).build());
        packingListRepository.save(packingList);
        return mapPacking(packingList);
    }

    @Override
    public PackingResponse toggleItem(String tripId, String itemId, TogglePackingItemRequest request) {
        PackingList packingList = getPackingList(tripId);
        PackingItem item = packingList.getCategories().stream()
                .flatMap(c -> c.getItems().stream())
                .filter(i -> i.getId().equals(itemId))
                .findFirst()
                .orElseThrow(() -> new ResourceNotFoundException("Packing item not found"));

        if (request.is_checked() != null) item.setChecked(request.is_checked());
        if (request.quantity() != null) item.setQuantity(request.quantity());
        packingListRepository.save(packingList);
        return mapPacking(packingList);
    }

    private PackingList getPackingList(String tripId) {
        Trip trip = ((TripServiceImpl) tripService).getOwnedTrip(tripId);
        return packingListRepository.findByTrip(trip).orElseThrow(() -> new ResourceNotFoundException("Packing list not found"));
    }

    private PackingResponse mapPacking(PackingList packingList) {
        return new PackingResponse(
                packingList.getTrip().getId(),
                packingList.getSelectedTransports(),
                packingList.getCategories().stream()
                        .map(c -> new PackingCategoryResponse(
                                c.getId(),
                                c.getName(),
                                c.getIcon(),
                                c.getItems().stream().map(i -> new PackingItemResponse(i.getId(), i.getName(), i.getChecked(), i.getQuantity())).toList()
                        ))
                        .toList()
        );
    }
}
