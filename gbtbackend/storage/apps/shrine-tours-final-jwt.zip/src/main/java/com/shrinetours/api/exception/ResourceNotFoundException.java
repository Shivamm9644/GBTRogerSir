package com.shrinetours.api.exception; public class ResourceNotFoundException extends RuntimeException { public ResourceNotFoundException(String message){ super(message);} }
