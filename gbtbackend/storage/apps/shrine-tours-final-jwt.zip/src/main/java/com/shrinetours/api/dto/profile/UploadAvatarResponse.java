package com.shrinetours.api.dto.profile;

public record UploadAvatarResponse(
        String avatarUrl
) {
}
