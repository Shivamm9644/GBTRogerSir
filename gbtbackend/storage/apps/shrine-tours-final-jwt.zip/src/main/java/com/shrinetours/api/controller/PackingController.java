package com.shrinetours.api.controller;

import com.shrinetours.api.dto.common.ApiResponse;
import com.shrinetours.api.dto.packing.*;
import com.shrinetours.api.service.PackingService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.List;

@RestController
@RequestMapping("/api/v1/packing")
@RequiredArgsConstructor
public class PackingController {

    private final PackingService packingService;

    @GetMapping
    public ResponseEntity<ApiResponse<PackingResponse>> getPacking(@RequestParam("trip_id") String tripId) {
        PackingResponse response = packingService.getPacking(tripId);
        return ResponseEntity.ok(ApiResponse.<PackingResponse>builder().success(true).message("Packing list fetched successfully").data(response).timestamp(LocalDateTime.now()).path("/api/v1/packing").build());
    }

    @GetMapping("/categories")
    public ResponseEntity<ApiResponse<List<PackingTemplateResponse>>> getCategories() {
        List<PackingTemplateResponse> response = packingService.getCategories();
        return ResponseEntity.ok(ApiResponse.<List<PackingTemplateResponse>>builder().success(true).message("Packing categories fetched successfully").data(response).timestamp(LocalDateTime.now()).path("/api/v1/packing/categories").build());
    }

    @PostMapping("/{tripId}/add-item")
    public ResponseEntity<ApiResponse<PackingResponse>> addItem(@PathVariable String tripId, @Valid @RequestBody AddPackingItemRequest request) {
        PackingResponse response = packingService.addItem(tripId, request);
        return ResponseEntity.status(HttpStatus.CREATED).body(ApiResponse.<PackingResponse>builder().success(true).message("Packing item added successfully").data(response).timestamp(LocalDateTime.now()).path("/api/v1/packing/" + tripId + "/add-item").build());
    }

    @PutMapping("/{tripId}/toggle-item/{itemId}")
    public ResponseEntity<ApiResponse<PackingResponse>> toggleItem(@PathVariable String tripId, @PathVariable String itemId, @RequestBody TogglePackingItemRequest request) {
        PackingResponse response = packingService.toggleItem(tripId, itemId, request);
        return ResponseEntity.ok(ApiResponse.<PackingResponse>builder().success(true).message("Packing item updated successfully").data(response).timestamp(LocalDateTime.now()).path("/api/v1/packing/" + tripId + "/toggle-item/" + itemId).build());
    }
}
