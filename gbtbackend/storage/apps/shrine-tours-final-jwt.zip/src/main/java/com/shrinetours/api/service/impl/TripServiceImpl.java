package com.shrinetours.api.service.impl;

import com.shrinetours.api.dto.itinerary.ActivityResponse;
import com.shrinetours.api.dto.place.PlaceResponse;
import com.shrinetours.api.dto.trip.*;
import com.shrinetours.api.entity.*;
import com.shrinetours.api.exception.BadRequestException;
import com.shrinetours.api.exception.ResourceNotFoundException;
import com.shrinetours.api.repository.*;
import com.shrinetours.api.service.AnalyticsService;
import com.shrinetours.api.service.TripService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@Slf4j
@Service
@RequiredArgsConstructor
@Transactional
public class TripServiceImpl implements TripService {

    private final TripRepository tripRepository;
    private final UserRepository userRepository;
    private final ItineraryRepository itineraryRepository;
    private final PlaceRepository placeRepository;
    private final TripPlaceRepository tripPlaceRepository;
    private final PackingListRepository packingListRepository;
    private final PackingCategoryRepository packingCategoryRepository;
    private final AnalyticsService analyticsService;

    @Override
    @Transactional(readOnly = true)
    public List<TripSummaryResponse> getTrips() {
        User user = getDemoUser();
        return tripRepository.findByUserOrderByStartDateDesc(user).stream().map(this::mapTripSummary).toList();
    }

    @Override
    @Transactional(readOnly = true)
    public TripSummaryResponse getTripById(String id) {
        return mapTripSummary(getOwnedTrip(id));
    }

    @Override
    public TripSummaryResponse createTrip(CreateTripRequest request) {
        validateDates(request.start_date(), request.end_date());
        Trip trip = createTripInternal(
                request.city(), request.start_date(), request.end_date(), request.adults(),
                request.kids(), "manual", defaultImage(), List.of()
        );
        analyticsService.track("trip_created", Map.of("tripId", trip.getId(), "city", trip.getCity()));
        return mapTripSummary(trip);
    }

    @Override
    public GeneratedTripResponse generateTrip(GenerateTripRequest request) {
        validateDates(request.start_date(), request.end_date());
        Trip trip = createTripInternal(
                request.city(), request.start_date(), request.end_date(), request.adults(),
                request.kids(), request.trip_style() == null || request.trip_style().isBlank() ? "balanced" : request.trip_style(),
                defaultImage(), request.selected_places() == null ? List.of() : request.selected_places()
        );
        Itinerary itinerary = buildItinerary(trip, trip.getCity(), trip.getDays());
        itineraryRepository.save(itinerary);
        packingListRepository.save(buildPackingList(trip));
        analyticsService.track("trip_generated", Map.of("tripId", trip.getId(), "itineraryId", itinerary.getId()));
        return new GeneratedTripResponse(trip.getId(), itinerary.getId(), trip.getCity(), trip.getStartDate(), trip.getEndDate(), trip.getDays(), trip.getTripStyle());
    }

    @Override
    @Transactional(readOnly = true)
    public TripDetailResponse getTripDetail(String id) {
        Trip trip = getOwnedTrip(id);
        List<PlaceResponse> places = tripPlaceRepository.findByTrip(trip).stream().map(TripPlace::getPlace).map(this::mapPlace).toList();
        if (places.isEmpty()) {
            places = placeRepository.findByCityIgnoreCase(trip.getCity()).stream().limit(Math.max(1, trip.getPlacesCount())).map(this::mapPlace).toList();
        }
        String itineraryId = itineraryRepository.findByTrip(trip).map(Itinerary::getId).orElse(null);
        return new TripDetailResponse(
                trip.getId(), trip.getCity(), trip.getImageUrl(), trip.getStartDate(), trip.getEndDate(),
                trip.getPlacesCount(), trip.getDays(), trip.getAdults(), trip.getKids(), trip.getTripStyle(), itineraryId, places
        );
    }

    @Override
    public TripDetailResponse updateTrip(String id, UpdateTripRequest request) {
        Trip trip = getOwnedTrip(id);
        if (request.city() != null) trip.setCity(request.city());
        if (request.start_date() != null) trip.setStartDate(request.start_date());
        if (request.end_date() != null) trip.setEndDate(request.end_date());
        if (request.adults() != null) trip.setAdults(request.adults());
        if (request.kids() != null) trip.setKids(request.kids());
        if (request.trip_style() != null) trip.setTripStyle(request.trip_style());
        if (request.image_url() != null) trip.setImageUrl(request.image_url());
        if (trip.getStartDate() != null && trip.getEndDate() != null) validateDates(trip.getStartDate(), trip.getEndDate());
        trip.setDays(calculateDays(trip.getStartDate(), trip.getEndDate()));
        if (request.place_ids() != null) {
            tripPlaceRepository.findByTrip(trip).forEach(tripPlaceRepository::delete);
            for (String placeId : request.place_ids()) {
                placeRepository.findById(placeId).ifPresent(place -> tripPlaceRepository.save(TripPlace.builder().trip(trip).place(place).build()));
            }
            trip.setPlacesCount(request.place_ids().size());
        }
        tripRepository.save(trip);
        analyticsService.track("trip_updated", Map.of("tripId", trip.getId()));
        return getTripDetail(id);
    }

    @Override
    public void deleteTrip(String id) {
        Trip trip = getOwnedTrip(id);
        itineraryRepository.findByTrip(trip).ifPresent(itineraryRepository::delete);
        packingListRepository.findByTrip(trip).ifPresent(packingListRepository::delete);
        tripPlaceRepository.findByTrip(trip).forEach(tripPlaceRepository::delete);
        tripRepository.delete(trip);
        analyticsService.track("trip_deleted", Map.of("tripId", id));
    }

    @Override
    public void addPlaceToTrip(String tripId, String placeId) {
        Trip trip = getOwnedTrip(tripId);
        Place place = placeRepository.findById(placeId).orElseThrow(() -> new ResourceNotFoundException("Place not found"));
        if (!tripPlaceRepository.existsByTripIdAndPlaceId(tripId, placeId)) {
            tripPlaceRepository.save(TripPlace.builder().trip(trip).place(place).build());
            trip.setPlacesCount(tripPlaceRepository.findByTrip(trip).size());
            tripRepository.save(trip);
        }
    }

    public Trip getOwnedTrip(String id) {
        Trip trip = tripRepository.findById(id).orElseThrow(() -> new ResourceNotFoundException("Trip not found"));
        if (!trip.getUser().getId().equals(getDemoUser().getId())) {
            throw new ResourceNotFoundException("Trip not found");
        }
        return trip;
    }

    private Trip createTripInternal(String city, LocalDate startDate, LocalDate endDate, Integer adults, Integer kids, String tripStyle, String imageUrl, List<String> placeIds) {
        Trip trip = tripRepository.save(
                Trip.builder()
                        .user(getDemoUser())
                        .city(city)
                        .imageUrl(imageUrl)
                        .startDate(startDate)
                        .endDate(endDate)
                        .placesCount(placeIds == null ? 0 : placeIds.size())
                        .days(calculateDays(startDate, endDate))
                        .adults(adults)
                        .kids(kids)
                        .tripStyle(tripStyle)
                        .build()
        );
        if (placeIds != null) {
            for (String placeId : placeIds) {
                placeRepository.findById(placeId).ifPresent(place -> tripPlaceRepository.save(TripPlace.builder().trip(trip).place(place).build()));
            }
        }
        return trip;
    }

    private Itinerary buildItinerary(Trip trip, String city, Integer days) {
        List<ItineraryDay> itineraryDays = new ArrayList<>();
        for (int i = 1; i <= Math.max(1, days); i++) {
            itineraryDays.add(ItineraryDay.builder()
                    .dayNumber(i)
                    .activities(new ArrayList<>(List.of(
                            Activity.builder().activityTime("08:30 AM").title("Start from hotel").duration("30 min").cost(BigDecimal.ZERO).icon("car").build(),
                            Activity.builder().activityTime("10:00 AM").title(city + " temple visit and local sightseeing").duration("3 hr").cost(new BigDecimal("500")).icon("temple").build()
                    )))
                    .build());
        }
        return Itinerary.builder()
                .trip(trip)
                .city(city)
                .title(city + " Smart Itinerary")
                .days(itineraryDays)
                .build();
    }

    private PackingList buildPackingList(Trip trip) {
        List<PackingCategory> templates = packingCategoryRepository.findByTemplateOnlyTrue();
        List<PackingCategory> categories = new ArrayList<>();
        for (PackingCategory template : templates) {
            List<PackingItem> items = template.getItems().stream()
                    .map(item -> PackingItem.builder().name(item.getName()).checked(false).quantity(item.getQuantity()).build())
                    .toList();
            categories.add(PackingCategory.builder().name(template.getName()).icon(template.getIcon()).templateOnly(false).items(new ArrayList<>(items)).build());
        }
        return PackingList.builder()
                .trip(trip)
                .selectedTransports(new ArrayList<>(List.of("car", "walking")))
                .categories(categories)
                .build();
    }

    private void validateDates(LocalDate startDate, LocalDate endDate) {
        if (endDate.isBefore(startDate)) {
            throw new BadRequestException("End date cannot be before start date");
        }
    }

    private int calculateDays(LocalDate startDate, LocalDate endDate) {
        return (int) ChronoUnit.DAYS.between(startDate, endDate) + 1;
    }

    private User getDemoUser() {
        return userRepository.findByEmailIgnoreCase("demo@shrinetours.com")
                .orElseThrow(() -> new ResourceNotFoundException("Demo user not found"));
    }

    private TripSummaryResponse mapTripSummary(Trip trip) {
        return new TripSummaryResponse(trip.getId(), trip.getCity(), trip.getImageUrl(), trip.getStartDate(), trip.getEndDate(), trip.getPlacesCount(), trip.getDays(), trip.getAdults(), trip.getKids());
    }

    private PlaceResponse mapPlace(Place place) {
        return new PlaceResponse(place.getId(), place.getName(), place.getCategory(), place.getImageUrl(), place.getTypicalDuration(), place.getRating(), place.getReviewsCount(), place.isVerified());
    }

    private String defaultImage() {
        return "https://images.unsplash.com/photo-1599661046289-e31897846e41?q=80&w=1200&auto=format&fit=crop";
    }
}
