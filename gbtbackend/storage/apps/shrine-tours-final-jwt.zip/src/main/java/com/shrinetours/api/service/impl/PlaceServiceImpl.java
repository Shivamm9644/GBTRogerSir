package com.shrinetours.api.service.impl;

import com.shrinetours.api.dto.place.AddPlaceToTripRequest;
import com.shrinetours.api.dto.place.PlaceResponse;
import com.shrinetours.api.entity.Place;
import com.shrinetours.api.exception.ResourceNotFoundException;
import com.shrinetours.api.repository.PlaceRepository;
import com.shrinetours.api.service.PlaceService;
import com.shrinetours.api.service.TripService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.List;

@Slf4j
@Service
@RequiredArgsConstructor
public class PlaceServiceImpl implements PlaceService {

    private final PlaceRepository placeRepository;
    private final TripService tripService;

    @Override
    public List<PlaceResponse> getPlaces(String city) {
        List<Place> places = (city == null || city.isBlank()) ? placeRepository.findAll() : placeRepository.findByCityIgnoreCase(city);
        return places.stream().map(this::mapPlace).toList();
    }

    @Override
    public List<PlaceResponse> search(String q) {
        return placeRepository.findByNameContainingIgnoreCaseOrCityContainingIgnoreCase(q, q).stream().map(this::mapPlace).toList();
    }

    @Override
    public List<PlaceResponse> suggested() {
        return placeRepository.findBySuggestedTrue().stream().map(this::mapPlace).toList();
    }

    @Override
    public PlaceResponse getPlace(String id) {
        return placeRepository.findById(id).map(this::mapPlace).orElseThrow(() -> new ResourceNotFoundException("Place not found"));
    }

    @Override
    public void addToTrip(AddPlaceToTripRequest request) {
        tripService.addPlaceToTrip(request.trip_id(), request.place_id());
    }

    private PlaceResponse mapPlace(Place place) {
        return new PlaceResponse(place.getId(), place.getName(), place.getCategory(), place.getImageUrl(), place.getTypicalDuration(), place.getRating(), place.getReviewsCount(), place.isVerified());
    }
}
