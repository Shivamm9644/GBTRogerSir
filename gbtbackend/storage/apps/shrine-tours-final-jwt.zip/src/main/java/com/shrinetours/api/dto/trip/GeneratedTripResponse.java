package com.shrinetours.api.dto.trip;

import java.time.LocalDate;

public record GeneratedTripResponse(
        String tripId,
        String itineraryId,
        String city,
        LocalDate startDate,
        LocalDate endDate,
        Integer days,
        String tripStyle
) {
}
