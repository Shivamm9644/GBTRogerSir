package com.shrinetours.api.dto.place;

import java.math.BigDecimal;

public record PlaceResponse(
        String id,
        String name,
        String category,
        String imageUrl,
        String typicalDuration,
        BigDecimal rating,
        Integer reviewsCount,
        boolean verified
) {
}
