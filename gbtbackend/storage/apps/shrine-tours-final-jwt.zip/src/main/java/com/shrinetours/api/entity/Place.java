package com.shrinetours.api.entity;

import com.shrinetours.api.common.entity.BaseEntity;
import jakarta.persistence.*;
import lombok.*;

import java.math.BigDecimal;
import java.util.UUID;

@Entity
@Table(name = "places", indexes = {
        @Index(name = "idx_places_city", columnList = "city"),
        @Index(name = "idx_places_city_suggested", columnList = "city,suggested")
})
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Place extends BaseEntity {
    @Id
    private String id;

    @Column(nullable = false)
    private String name;

    @Column(nullable = false)
    private String city;

    @Column(nullable = false)
    private String category;

    private String imageUrl;
    private String typicalDuration;

    @Column(nullable = false, precision = 3, scale = 1)
    private BigDecimal rating;

    @Column(nullable = false)
    private Integer reviewsCount;

    @Column(nullable = false)
    private boolean verified;

    @Column(nullable = false)
    private boolean suggested;

    @PrePersist
    public void prePersist() {
        if (id == null) id = UUID.randomUUID().toString();
        if (rating == null) rating = BigDecimal.ZERO;
        if (reviewsCount == null) reviewsCount = 0;
    }
}
