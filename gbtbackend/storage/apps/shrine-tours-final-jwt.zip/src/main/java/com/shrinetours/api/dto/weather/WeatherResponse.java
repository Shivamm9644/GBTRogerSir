package com.shrinetours.api.dto.weather;

import java.time.LocalDate;

public record WeatherResponse(
        String city,
        LocalDate date,
        String condition,
        Integer minTemp,
        Integer maxTemp,
        String summary,
        Integer precipitationChance,
        String wind,
        Integer humidity
) {
}
