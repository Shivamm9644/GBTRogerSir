package com.shrinetours.api.repository;

import com.shrinetours.api.entity.Trip;
import com.shrinetours.api.entity.TripPlace;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface TripPlaceRepository extends JpaRepository<TripPlace, String> {
    List<TripPlace> findByTrip(Trip trip);
    boolean existsByTripIdAndPlaceId(String tripId, String placeId);
}
