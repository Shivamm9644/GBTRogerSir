package com.shrinetours.api.service;

import com.shrinetours.api.dto.packing.*;

import java.util.List;

public interface PackingService {
    PackingResponse getPacking(String tripId);
    List<PackingTemplateResponse> getCategories();
    PackingResponse addItem(String tripId, AddPackingItemRequest request);
    PackingResponse toggleItem(String tripId, String itemId, TogglePackingItemRequest request);
}
